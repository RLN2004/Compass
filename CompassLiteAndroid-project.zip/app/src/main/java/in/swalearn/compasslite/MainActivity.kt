package in.swalearn.compasslite

import android.app.Activity
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Typeface
import android.view.ViewGroup
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var rotationSensor: Sensor? = null
    private lateinit var dial: CompassDial
    private lateinit var headingText: TextView
    private lateinit var directionText: TextView
    private lateinit var statusText: TextView
    private var heading = 0f
    private var hasSensor = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 18, 32)
        window.navigationBarColor = Color.rgb(10, 18, 32)
        window.decorView.systemUiVisibility = 0

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        hasSensor = rotationSensor != null

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(Color.rgb(10, 18, 32))
        }

        val title = TextView(this).apply {
            text = "COMPASS LITE"
            textSize = 14f
            letterSpacing = 0.18f
            setTextColor(Color.rgb(147, 166, 197))
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(36)))

        headingText = TextView(this).apply {
            text = "—°"
            textSize = 48f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        root.addView(headingText, LinearLayout.LayoutParams(-1, dp(66)))

        directionText = TextView(this).apply {
            text = "Point your phone away from metal"
            textSize = 16f
            setTextColor(Color.rgb(105, 190, 255))
            gravity = Gravity.CENTER
        }
        root.addView(directionText, LinearLayout.LayoutParams(-1, dp(32)))

        dial = CompassDial(this)
        root.addView(dial, LinearLayout.LayoutParams(-1, 0, 1f))

        statusText = TextView(this).apply {
            text = if (hasSensor) "Waiting for compass sensor…" else "This phone does not expose a rotation-vector sensor."
            textSize = 13f
            setTextColor(Color.rgb(147, 166, 197))
            gravity = Gravity.CENTER
        }
        root.addView(statusText, LinearLayout.LayoutParams(-1, dp(42)))

        val tip = TextView(this).apply {
            text = "Calibration: move your phone in a figure-eight.
Keep it away from magnets and metal cases."
            textSize = 12f
            setTextColor(Color.rgb(120, 136, 160))
            gravity = Gravity.CENTER
        }
        root.addView(tip, LinearLayout.LayoutParams(-1, dp(56)))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        rotationSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        val matrix = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(matrix, event.values)
        val orientation = FloatArray(3)
        SensorManager.getOrientation(matrix, orientation)
        var degrees = Math.toDegrees(orientation[0].toDouble()).toFloat()
        degrees = (degrees + 360f) % 360f
        // Smooth wrap-around using the shortest angular difference.
        var delta = ((degrees - heading + 540f) % 360f) - 180f
        heading = (heading + delta * 0.22f + 360f) % 360f
        val rounded = Math.round(heading) % 360
        headingText.text = String.format(Locale.US, "%03d°", rounded)
        directionText.text = directionFor(heading)
        statusText.text = "Live sensor • Magnetic north"
        dial.heading = heading
        dial.invalidate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        statusText.text = when (accuracy) {
            SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> "Sensor accuracy: high"
            SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> "Sensor accuracy: medium"
            SensorManager.SENSOR_STATUS_ACCURACY_LOW -> "Low accuracy • move in a figure-eight"
            else -> "Calibrating sensor…"
        }
    }

    private fun directionFor(deg: Float): String {
        val names = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
        return names[(Math.round(deg / 45f) % 8)] + "  •  " + when ((Math.round(deg / 45f) % 8)) {
            0 -> "North"; 1 -> "North-East"; 2 -> "East"; 3 -> "South-East"
            4 -> "South"; 5 -> "South-West"; 6 -> "West"; else -> "North-West"
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    inner class CompassDial(context: Context) : View(context) {
        var heading: Float = 0f
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = Color.rgb(53, 72, 99) }
        private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 2f; strokeCap = Paint.Cap.ROUND; color = Color.rgb(116, 139, 171) }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); textSize = 16f; color = Color.WHITE }
        private val red = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 88, 88); style = Paint.Style.FILL }
        private val blue = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(105, 190, 255); style = Paint.Style.FILL }
        private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(10, 18, 32); style = Paint.Style.FILL }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val r = (minOf(width, height) * 0.42f)
            canvas.drawCircle(cx, cy, r, ring)
            canvas.drawCircle(cx, cy, r * 0.72f, ring.apply { alpha = 90 })
            for (i in 0 until 72) {
                val a = Math.toRadians((i * 5 - 90).toDouble())
                val major = i % 9 == 0
                val len = if (major) r * 0.13f else if (i % 3 == 0) r * 0.08f else r * 0.04f
                val x1 = cx + cos(a).toFloat() * (r - len)
                val y1 = cy + sin(a).toFloat() * (r - len)
                val x2 = cx + cos(a).toFloat() * (r - 5f)
                val y2 = cy + sin(a).toFloat() * (r - 5f)
                tick.strokeWidth = if (major) 2.5f else 1.2f
                canvas.drawLine(x1, y1, x2, y2, tick)
            }
            val labels = arrayOf("N", "E", "S", "W")
            for (i in 0..3) {
                val angle = Math.toRadians((i * 90 - 90).toDouble())
                val x = cx + cos(angle).toFloat() * (r * 0.79f)
                val y = cy + sin(angle).toFloat() * (r * 0.79f) + text.textSize / 3f
                text.color = if (i == 0) Color.rgb(255, 88, 88) else Color.WHITE
                canvas.drawText(labels[i], x, y, text)
            }
            // Rotating needle: red points toward magnetic north.
            canvas.save()
            canvas.rotate(-heading, cx, cy)
            val path = android.graphics.Path().apply {
                moveTo(cx, cy - r * 0.60f)
                lineTo(cx - r * 0.09f, cy + r * 0.03f)
                lineTo(cx + r * 0.09f, cy + r * 0.03f)
                close()
            }
            canvas.drawPath(path, red)
            val south = android.graphics.Path().apply {
                moveTo(cx, cy + r * 0.60f)
                lineTo(cx - r * 0.09f, cy - r * 0.03f)
                lineTo(cx + r * 0.09f, cy - r * 0.03f)
                close()
            }
            canvas.drawPath(south, blue)
            canvas.restore()
            canvas.drawCircle(cx, cy, r * 0.055f, centerPaint)
            canvas.drawCircle(cx, cy, r * 0.025f, blue)
        }
    }
}
