# Compass Lite (Android)

A small native Android compass using the device rotation-vector sensor. It runs offline and requests no permissions.

## Build an APK
1. Install Android Studio on a computer and open this folder as a project.
2. Let Gradle sync and install the Android SDK Platform 35 if prompted.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

For a release APK, use **Build > Generate Signed Bundle / APK** and create a signing key.

## Notes
- Compass readings can be affected by magnets, metal, phone cases, and nearby electronics.
- Calibrate by moving the phone in a figure-eight.
- This displays magnetic heading, not true-north corrected heading.

## Build in GitHub Actions (without Android Studio)
Push this project to a GitHub repository, then open **Actions → Build Compass Lite APK → Run workflow**. When the run finishes, download the `CompassLite-debug-apk` artifact and extract `app-debug.apk`. This workflow requires the project to be pushed to your repository.
